#!/usr/bin/env python3
import os
import sys
import importlib.util
import builtins
import torch
from abc import ABC, abstractmethod
from typing import Dict, List, Any

# ==============================================================================
# 1. NAMESPACE BINDING (Fixes Observer Faults)
# ==============================================================================
class BaseObserver(ABC):
    """
    The Base Interface for all Holosyn Observers.
    """
    @abstractmethod
    def evaluate(self, s, sy, p, snn, **kwargs) -> float:
        return 0.5

# Inject into builtins so plugins can find it via: BaseObserver = getattr(builtins, "BaseObserver")
setattr(builtins, "BaseObserver", BaseObserver)
sys.modules['__main__'].BaseObserver = BaseObserver

# ==============================================================================
# 2. OMNI-VAULT LOADER
# ==============================================================================
class OmniVaultLoader:
    def __init__(self, root_path: str):
        self.root_path = root_path
        self.observers: Dict[str, BaseObserver] = {}
        self.weights: Dict[str, torch.Tensor] = {}
        
    def scan(self):
        """Recursively scans the vault for .py plugins and .pt weights."""
        print(f"\n💠 [OMNI-VAULT] Initiating recursive scan of: {self.root_path}")
        
        for root, _, files in os.walk(self.root_path):
            for file in files:
                full_path = os.path.join(root, file)
                
                if file.endswith(".py"):
                    self._ingest_plugin(full_path)
                elif file.endswith((".pt", ".pth", ".bin")):
                    self._ingest_weights(full_path, file)

    def _ingest_plugin(self, file_path: str):
        """Dynamically loads and instantiates observer classes."""
        module_name = f"plugin_{os.path.basename(file_path).split('.')[0]}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            found = False
            for attr in dir(module):
                obj = getattr(module, attr)
                # Verify inheritance from global BaseObserver
                if isinstance(obj, type) and issubclass(obj, BaseObserver) and obj is not BaseObserver:
                    self.observers[attr[:3].upper()] = obj()
                    print(f"   ✅ ACTIVATED OBSERVER: {attr} (via {os.path.basename(file_path)})")
                    found = True
            if not found:
                print(f"   ⚠️ No valid BaseObserver subclasses found in: {file_path}")
        except Exception as e:
            print(f"   ❌ PLUGIN FAULT [{file_path}]: {e}")

    def _ingest_weights(self, file_path: str, filename: str):
        """Loads state tensors into the registry."""
        try:
            w = torch.load(file_path, map_location='cpu', weights_only=False)
            self.weights[filename] = w
            print(f"   📦 ASSIMILATED WEIGHTS: {filename}")
        except Exception as e:
            print(f"   ⚠️ TENSOR FAULT: {filename} -> {e}")

# ==============================================================================
# 3. EXECUTION INTERFACE
# ==============================================================================
if __name__ == "__main__":
    vault_path = "/home/devcbloom"
    if not os.path.exists(vault_path):
        vault_path = "." # Fallback to local
        
    loader = OmniVaultLoader(vault_path)
    
    # Manual Trigger: You can call this again with a different path
    # loader.load_observer_plugin("/other/path/to/plugins")
    
    print("\n[Engine] Vault System Ready. Plugins activated.")